<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register page </title>
    <link rel="stylesheet" href="register.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<body>
   
    <div class = "wrapper">
        <form method = "post" action="register.php">

            <h3>Welcome to the SCOB000 data base register below :</h3>

            <div class="input-box" >
                <input id="name" name="name" type="text" placeholder="Name" required>
            </div>
            <div class="input-box" >
                <input id="surname" name="surname" type="text" placeholder="Surname" required>
            </div>

            <div class="input-box" >
                <input id="studentno" name="studentno" type="text" placeholder="e.g 202356821" required>
            </div>

            <div class="input-box" >
                <input id="contact" name="contact" type="tel" placeholder="e.g 0713452665" required>
            </div>

            <div class="input-box" >
                <input id="modulecode" name="modulecode" type="text" placeholder="e.g SMTH000" required>
            </div>

            <div class="input-box" >
                <input id="email" name="email" type="email" placeholder="example@mail.com" required>
            </div>


            <div class="input-box">
                <input id="password" name="password" type="password" placeholder="password" required>
            </div>

            <div class="input-box">
                <input id="confirmpassword" name="confirmpassword" type="password" placeholder="confirm password" required>
            </div>
            <button type="submit" class="btn" name= "registerbtn">Register</button>
           
            <div class="login-linky">
                <p>Already have an account? 
                    <a href="loginpAGE.php">Login</a>   
                    </p>
            </div>

        </form>
        
    </div>
     <script src="register.js"></script>
</body>
<script src="index.js"></script>
</html>