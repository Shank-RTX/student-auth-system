<?php

include 'connect.php';

if (isset($_POST['registerbtn'])) {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $studentno = $_POST['studentno'];
    $contact = $_POST['contact'];
    $modulecode = $_POST['modulecode'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);
    $confirmpasspword = $_POST['confirmpassword'];
    $confirmpasspword = md5($confirmpasspword); // Removed extra dollar sign

    $checkEmail = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($checkEmail);
    if ($result->num_rows > 0) { // Corrected property name
        echo "Email Address Already Exists!";
    } else {
        $insertQuery = "INSERT INTO users(first_name, surname, student_number, contact_number, module_code, email, password, confirm_password)
        VALUES ('$name', '$surname', '$studentno', '$contact', '$modulecode', '$email', '$password', '$confirmpasspword')";
        
        if ($conn->query($insertQuery) == TRUE) {
            header("Location: registerpage.php");
            exit(); // It's a good practice to call exit after a header redirect
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

if (isset($_POST['loginbtn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password); // Corrected variable name

    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $results = $conn->query($sql);
    
    if ($results->num_rows > 0) { // Corrected property name
        session_start();
        $row = $results->fetch_assoc();
        $_SESSION['email'] = $row['email'];
        header("Location: homepage.php");
        exit(); // Added exit here as well
    } else {
        echo "Not found, Incorrect Email or Password";
    }
}
?>
