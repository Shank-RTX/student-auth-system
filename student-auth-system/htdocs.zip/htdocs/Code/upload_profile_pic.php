<?php
session_start();
include 'connect.php'; // Database connection

// Ensure the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['email'];

if (isset($_POST['upload'])) {
    // Check if a file is uploaded
    if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] == 0) {
        $target_dir = "uploads/"; // Directory to store uploaded profile pictures
        $target_file = $target_dir . basename($_FILES["profilePic"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is an actual image
        $check = getimagesize($_FILES["profilePic"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        // Check the file size (limit to 2MB)
        if ($_FILES["profilePic"]["size"] > 2000000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow only JPG, JPEG, and PNG file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, and PNG files are allowed.";
            $uploadOk = 0;
        }

        // If everything is OK, try to upload the file
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["profilePic"]["tmp_name"], $target_file)) {
                // Update the profile picture path in the database
                $sql = "UPDATE users SET profile_pic='$target_file' WHERE email='$email'";
                if ($conn->query($sql) === TRUE) {
                    echo "Profile picture updated successfully!";
                    header("Location: homepage.php");
                    exit();
                } else {
                    echo "Error updating profile picture: " . $conn->error;
                }
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        echo "No file uploaded.";
    }
}
?>
