<?php
session_start();
include 'connect.php'; // Include the database connection

// Check if the user is logged in (assuming you're storing the user ID in the session)
if (!isset($_SESSION['email'])) {
    header("Location: loginpAGE.php "); // Redirect to login page if not logged in
    exit();
}

// Fetch user details from the database using the session email
$email = $_SESSION['email'];
$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['first_name'];
    $surname = $row['surname'];
    $studentno = $row['student_number'];
    $contact = $row['contact_number'];
    $modulecode = $row['module_code'];
    $profilePic = $row['profile_pic'] ?? 'default.jpg'; // Default image if none is set
} else {
    echo "User not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="profile.css">
</head>
<body>

<h1>Welcome, <?php echo $name . ' ' . $surname; ?>!</h1>

<!-- Display the profile picture -->
<div class="profile-picture">
    <img src="uploads/<?php echo $profilePic; ?>" alt="Profile Picture" width="150" height="150">
</div>

<!-- Display user details -->
<p>Student Number: <?php echo $studentno; ?></p>
<p>Contact: <?php echo $contact; ?></p>
<p>Module Code: <?php echo $modulecode; ?></p>
<p>Email: <?php echo $email; ?></p>

<!-- Form to update profile picture -->
<form action="upload_profile_pic.php" method="POST" enctype="multipart/form-data">
    <label for="profilePic">Change Profile Picture:</label>
    <input type="file" name="profilePic" id="profilePic">
    <button type="submit" name="upload">Upload</button>
</form>

</body>
</html>

