<?php 
session_start();
include("php/config.php");

if (!isset($_SESSION['valid'])) {
    header("Location: index.php");
    exit;
}

$id = $_SESSION['id'];
$query = mysqli_query($con, "SELECT * FROM users WHERE Id=$id");
$result = mysqli_fetch_assoc($query);

// Fill the form with the current values
$res_Uname = $result['Name'];
$res_Surname = $result['Surname'];
$res_Email = $result['Email'];
$res_Contact = $result['Contactno'];
$res_StudentNo = $result['Studentnumber'];
$res_ModuleCode = $result['Modulecode'];
$res_Password = $result['Password']; // You'll hash the new password when updating
$res_ProfilePicture = $result['ProfilePicture']; // Get the current profile picture

// Handle the profile picture update
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $surname = $_POST['usersurname'];
    $email = $_POST['email'];
    $contact = $_POST['contactno'];
    $studentnumber = $_POST['studentnumber'];
    $modulecode = $_POST['modulecode'];
    $password = $_POST['password'];
    
    // Check if password is provided and hash it
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    } else {
        $hashed_password = $res_Password;  // If password is empty, keep the old password
    }

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $file_name = $_FILES['profile_picture']['name'];
        $file_tmp = $_FILES['profile_picture']['tmp_name'];
        $file_size = $_FILES['profile_picture']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_ext = array('jpg', 'jpeg', 'png');
        $max_file_size = 5 * 1024 * 1024; // 5 MB
        
        // Validate file
        if (in_array($file_ext, $allowed_ext) && $file_size <= $max_file_size) {
            // Create a unique file name to avoid overwriting
            $new_file_name = time() . '.' . $file_ext;
            $upload_path = 'uploads/' . $new_file_name;

            // Move the file to the server
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Update the database with the new profile picture
                $update_query = "UPDATE users SET 
                                 Name='$username', 
                                 Surname='$surname', 
                                 Email='$email', 
                                 Contactno='$contact', 
                                 Studentnumber='$studentnumber', 
                                 Modulecode='$modulecode', 
                                 Password='$hashed_password', 
                                 ProfilePicture='$new_file_name' 
                                 WHERE Id=$id";
            } else {
                echo "<div class='message'><p>Error uploading profile picture.</p></div>";
                exit;
            }
        } else {
            echo "<div class='message'><p>Invalid file type or file size exceeds 5MB.</p></div>";
            exit;
        }
    } else {
        // If no new file is uploaded, just update the other fields
        $update_query = "UPDATE users SET 
                         Name='$username', 
                         Surname='$surname', 
                         Email='$email', 
                         Contactno='$contact', 
                         Studentnumber='$studentnumber', 
                         Modulecode='$modulecode', 
                         Password='$hashed_password' 
                         WHERE Id=$id";
    }

    // Execute the update query
    if (mysqli_query($con, $update_query)) {
        echo "<div class='message'><p>Profile Updated!</p></div><br>";
        echo "<a href='home.php'><button class='btn'>Go Home</button></a>";
    } else {
        echo "<div class='message'><p>Error updating profile: " . mysqli_error($con) . "</p></div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Edit Profile</title>
</head>
<body>
    <div class="nav">
        <div class="logo">
            <p><a href="home.php">Logo</a></p>
        </div>
        <div class="right-links">
            <a href="home.php">Home</a>
            <a href="php/logout.php"><button class="btn">Log Out</button></a>
        </div>
    </div>

    <div class="container">
        <div class="box form-box">
            <header>Edit Profile</header>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="field input">
                    <label for="username">Name</label>
                    <input type="text" name="username" id="username" value="<?php echo $res_Uname; ?>" required>
                </div>

                <div class="field input">
                    <label for="usersurname">Surname</label>
                    <input type="text" name="usersurname" id="usersurname" value="<?php echo $res_Surname; ?>" required>
                </div>

                <div class="field input">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo $res_Email; ?>" required>
                </div>

                <div class="field input">
                    <label for="contactno">Contact Number</label>
                    <input type="text" name="contactno" id="contactno" value="<?php echo $res_Contact; ?>" required>
                </div>

                <div class="field input">
                    <label for="studentnumber">Student Number</label>
                    <input type="text" name="studentnumber" id="studentnumber" value="<?php echo $res_StudentNo; ?>" required>
                </div>

                <div class="field input">
                    <label for="modulecode">Module Code</label>
                    <input type="text" name="modulecode" id="modulecode" value="<?php echo $res_ModuleCode; ?>" required>
                </div>

                <div class="field input">
                    <label for="password">New Password</label>
                    <input type="password" name="password" id="password" autocomplete="off">
                    <small>If you don't want to change your password, leave this field empty.</small>
                </div>

                <div class="field input">
                    <label for="profile_picture">Profile Picture</label>
                    <input type="file" name="profile_picture" id="profile_picture">
                    <small>Upload a new profile picture (optional)</small>
                </div>

                <div class="field">
                    <input type="submit" class="btn" name="submit" value="Update">
                </div>
            </form>
        </div>
    </div>
</body>
</html>
