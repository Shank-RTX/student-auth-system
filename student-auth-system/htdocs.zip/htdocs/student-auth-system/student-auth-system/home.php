<?php
session_start();
include("php/config.php");

if (!isset($_SESSION['valid'])) {
    header("Location: index.php");
    exit;
}

$id = $_SESSION['id'];
$query = mysqli_query($con, "SELECT * FROM users WHERE Id=$id");

$result = mysqli_fetch_assoc($query);

// Use correct column names from the database
$res_Uname = $result['Name'];
$res_Surname = $result['Surname'];
$res_Email = $result['Email'];
$res_Contact = $result['Contactno'];
$res_StudentNo = $result['Studentnumber'];
$res_ModuleCode = $result['Modulecode'];
$res_id = $result['Id'];
$res_ProfilePicture = $result['ProfilePicture']; // Get the profile picture path
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Home</title>
    <style>
        .info-block {
            background: #ffffff;
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            font-size: 16px;
        }
        .profile-picture {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="nav">
        <div class="logo">
            <p><a href="home.php">Logo</a></p>
        </div>
        <div class="right-links">
            <a href="edit.php?Id=<?php echo $res_id; ?>">Change Profile</a>
            <a href="php/logout.php"><button class="btn">Log Out</button></a>
        </div>
    </div>

    <main>
        <div class="main-box top">
            <div class="top">
                <div class="info-block">
                    <p>Hello <b><?php echo $res_Uname . ' ' . $res_Surname; ?></b>, welcome!</p>
                </div>
                <div class="info-block">
                    <p>Your email is <b><?php echo $res_Email; ?></b>.</p>
                </div>
            </div>
            <div class="bottom">
                <div class="info-block">
                    <p>Your contact number is <b><?php echo $res_Contact; ?></b>.</p>
                </div>
                <div class="info-block">
                    <p>Your student number is <b><?php echo $res_StudentNo; ?></b>.</p>
                </div>
                <div class="info-block">
                    <p>You're enrolled in module <b><?php echo $res_ModuleCode; ?></b>.</p>
                </div>
                <div class="info-block">
                    <!-- Display profile picture if it exists -->
                    <?php if ($res_ProfilePicture): ?>
                        <img src="uploads/<?php echo $res_ProfilePicture; ?>" alt="Profile Picture" class="profile-picture">
                    <?php else: ?>
                        <!-- If no profile picture, show a placeholder -->
                        <img src="uploads/default-profile.png" alt="Default Profile Picture" class="profile-picture">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
