<?php
include("php/config.php");

// Flag for checking if registration is successful
$registrationSuccess = false;

if (isset($_POST['submit'])) {
    $name = $_POST['username'];
    $surname = $_POST['usersurname'];
    $studentnumber = $_POST['studentnumber'];
    $modulecode = $_POST['modulecode'];
    $contactno = $_POST['contact-no'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Check if password and confirm password match
    if ($password !== $confirm_password) {
        echo "<div class='message'><p>Passwords do not match. Please try again.</p></div>";
    } else {
        // Check for uniqueness
        $emailCheck = mysqli_query($con, "SELECT Email FROM users WHERE Email='$email'");
        $studentCheck = mysqli_query($con, "SELECT Studentnumber FROM users WHERE Studentnumber='$studentnumber'");
        $contactCheck = mysqli_query($con, "SELECT Contactno FROM users WHERE Contactno='$contactno'");

        if (mysqli_num_rows($emailCheck) > 0) {
            echo "<div class='message'><p>Email already registered.</p></div>";
        } elseif (mysqli_num_rows($studentCheck) > 0) {
            echo "<div class='message'><p>Student number already used.</p></div>";
        } elseif (mysqli_num_rows($contactCheck) > 0) {
            echo "<div class='message'><p>Contact number already exists.</p></div>";
        } else {
            // Handle profile picture upload
            $profile_picture = null;
            if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
                $file_name = $_FILES['profile_picture']['name'];
                $file_tmp = $_FILES['profile_picture']['tmp_name'];
                $file_size = $_FILES['profile_picture']['size'];
                $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                
                $allowed_ext = array('jpg', 'jpeg', 'png');
                $max_file_size = 5 * 1024 * 1024; // 5 MB
                
                // Validate file
                if (in_array($file_ext, $allowed_ext) && $file_size <= $max_file_size) {
                    // Create a unique file name to avoid overwriting
                    $new_file_name = time() . '.' . $file_ext;
                    $upload_path = 'uploads/' . $new_file_name;

                    // Move the file to the server
                    if (move_uploaded_file($file_tmp, $upload_path)) {
                        $profile_picture = $new_file_name;
                    } else {
                        echo "<div class='message'><p>Error uploading profile picture.</p></div>";
                        exit;
                    }
                } else {
                    echo "<div class='message'><p>Invalid file type or file size exceeds 5MB.</p></div>";
                    exit;
                }
            }

            // Hash password and insert
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO users (Name, Surname, Studentnumber, Contactno, Modulecode, Email, Password, ProfilePicture)
                             VALUES ('$name', '$surname', '$studentnumber', '$contactno', '$modulecode', '$email', '$hashed_password', '$profile_picture')";

            if (mysqli_query($con, $insert_query)) {
                // Set the registration success flag
                $registrationSuccess = true;
            } else {
                echo "<div class='message'><p>Database error: " . mysqli_error($con) . "</p></div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Register</title>
</head>
<body>
    <div class="container">
        <?php if (!$registrationSuccess): ?>
            <div class="box form-box" id="registerForm">
                <header>Sign Up</header>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="field input">
                        <label for="username">Name</label>
                        <input type="text" name="username" id="username" required>
                    </div>
                    <div class="field input">
                        <label for="usersurname">Surname</label>
                        <input type="text" name="usersurname" id="usersurname" required>
                    </div>
                    <div class="field input">
                        <label for="studentnumber">Student Number</label>
                        <input type="text" name="studentnumber" id="studentnumber" required>
                    </div>
                    <div class="field input">
                        <label for="modulecode">Module Code</label>
                        <input type="text" name="modulecode" id="modulecode" required>
                    </div>
                    <div class="field input">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    <div class="field input">
                        <label for="contact-no">Contact No</label>
                        <input type="text" name="contact-no" id="contact-no" required>
                    </div>
                    <div class="field input">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" required>
                    </div>
                    <div class="field input">
                        <label for="confirm-password">Confirm Password</label>
                        <input type="password" name="confirm-password" id="confirm-password" required>
                    </div>

                    <div class="field input">
                        <label for="profile_picture">Profile Picture</label>
                        <input type="file" name="profile_picture" id="profile_picture">
                        <small>Upload a profile picture (optional)</small>
                    </div>

                    <div class="field">
                        <input type="submit" class="btn" name="submit" value="Register">
                    </div>
                    <div class="links">
                        Already a member? <a href="index.php">Sign In</a>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="message">
                <p>Registration successful!</p>
                <form action="index.php" method="get">
                    <button type="submit" class="btn">Login Now</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
