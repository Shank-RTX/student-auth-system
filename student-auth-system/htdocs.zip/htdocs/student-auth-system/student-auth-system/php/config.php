<?php
$servername = "localhost";  // Your DB server (usually 'localhost')
$username = "root";  // Your DB username (usually 'root' for local)
$password = "";  // Your DB password (blank for XAMPP by default)
$dbname = "tutorial";  // Your database name

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
